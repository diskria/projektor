package io.github.diskria.projektor

import kotlin.String

public object ProjektBuildConfig {
  public const val PLUGIN_ID: String = "io.github.diskria.projektor"

  public const val PLUGIN_NAME: String = "Projektor"
}
