package io.github.diskria.projektor

import kotlin.String

public object ProjektBuildConfig {
  public const val LIBRARY_NAME: String = "Projektor"
}
