package io.github.diskria.projektor.projekt

import io.github.diskria.kotlin.utils.Constants
import io.github.diskria.kotlin.utils.extensions.appendPackageName
import io.github.diskria.kotlin.utils.extensions.common.fileName
import io.github.diskria.kotlin.utils.extensions.common.modifyIf
import io.github.diskria.kotlin.utils.extensions.setCase
import io.github.diskria.kotlin.utils.words.*
import io.github.diskria.projektor.extensions.mappers.toJvmTarget
import io.github.diskria.projektor.licenses.License
import io.github.diskria.projektor.minecraft.ModEnvironment
import io.github.diskria.projektor.minecraft.ModLoader
import io.github.diskria.projektor.minecraft.version.MinecraftVersion
import io.github.diskria.projektor.owner.GithubOwner
import io.github.diskria.projektor.owner.ProjektOwner
import io.github.diskria.projektor.properties.toAutoNamedGradleProperty
import org.gradle.api.Project
import org.gradle.kotlin.dsl.provideDelegate
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

data class Projekt(
    override val owner: ProjektOwner,
    override val license: License,
    override val name: String,
    override val description: String,
    override val version: String,
    override val slug: String,
    override val packageName: String,
    override val packagePath: String = packageName.setCase(DotCase, PathCase),
    override val classNameBase: String = name.setCase(SpaceCase, PascalCase),
    override val javaVersion: Int,
    override val jvmTarget: JvmTarget,
    override val kotlinVersion: String,
    override val scm: ScmType = ScmType.GIT,
    override val softwareForge: SoftwareForgeType = owner.softwareForgeType,
) : IProjekt {

    fun toGradlePlugin(isSettingsPlugin: Boolean): GradlePlugin =
        GradlePlugin(
            id = packageName.modifyIf(isSettingsPlugin) { it.appendPackageName("settings") },
            className = classNameBase.modifyIf(isSettingsPlugin) { it + "Settings" } + "GradlePlugin",
            delegate = this,
        )

    fun toLibrary(): Library =
        Library(this)

    fun toMinecraftMod(
        modLoader: ModLoader,
        minecraftVersion: MinecraftVersion,
        environment: ModEnvironment,
        modrinthProjectUrl: String,
    ): MinecraftMod {
        val modId = slug
        return MinecraftMod(
            id = modId,
            modLoader = modLoader,
            minecraftVersion = minecraftVersion,
            environment = environment,
            modrinthProjectUrl = modrinthProjectUrl,
            mixinsConfigFileName = fileName(modId, "mixins", Constants.File.Extension.JSON),
            delegate = this,
        )
    }

    fun toAndroidApp(): AndroidApp =
        AndroidApp(this)

    companion object {
        fun of(project: Project, owner: GithubOwner, license: License, jvmTarget: JvmTarget? = null): Projekt {
            val projectName by project.providers.toAutoNamedGradleProperty()
            val projectDescription by project.providers.toAutoNamedGradleProperty()
            val projectVersion by project.providers.toAutoNamedGradleProperty()
            val javaVersion = Versions.JAVA
            return Projekt(
                owner = owner,
                license = license,
                name = projectName,
                description = projectDescription,
                version = projectVersion,
                slug = projectName.setCase(SpaceCase, KebabCase).lowercase(),
                packageName = owner.namespace + Constants.Char.DOT + projectName.setCase(SpaceCase, DotCase),
                javaVersion = javaVersion,
                jvmTarget = jvmTarget ?: javaVersion.toJvmTarget(),
                kotlinVersion = Versions.KOTLIN,
            )
        }
    }
}
