package io.github.diskria.projektor.settings

import kotlin.String

public object ProjektBuildConfig {
  public const val PLUGIN_ID: String = "io.github.diskria.projektor.settings"

  public const val PLUGIN_NAME: String = "Projektor"
}
